export default class PostsModel {
    constructor(userId, caption) {
        this.userId = userId;
        this.caption = caption;
        this.imageUrl = [];
    }
}